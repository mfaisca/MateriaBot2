package com.corhm.cultbot.commands;
import java.util.List;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.LinkedList;
import com.corhm.cultbot.Utils.*;
import sx.blah.discord.handle.impl.events.guild.channel.message.MessageReceivedEvent;
import sx.blah.discord.handle.impl.events.guild.channel.message.reaction.ReactionAddEvent;

public abstract class _BaseCommand{
    public static final String BOT_PREFIX;
	protected final String command;
	protected final List<String> commands = new LinkedList<String>();
	
	static {
		String p = "$";
		try {
			 p = (InetAddress.getLocalHost().getHostName().equalsIgnoreCase("DESKTOP-NLBHP8D") || InetAddress.getLocalHost().getHostName().equalsIgnoreCase("HEAVEN")) ? "%" : "$";
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BOT_PREFIX = p;
	}

	public _BaseCommand(final String command, final String... commands){
		this.command = command;
		this.commands.add(command);
		for(String s : commands)
			this.commands.add(s);
		System.out.println("Command " + command + " has been registered.");
	}
	
	protected final String getCommand() { return command; }
	protected final List<String> getCommands() { return commands; }

	protected abstract void doStuff(final MessageReceivedEvent event);
	protected void doReactionStuff(final ReactionAddEvent event) {}
	
	protected abstract String help(final MessageReceivedEvent event, Constants.HELP_TYPE helpType);

	public String getFunction(MessageReceivedEvent event) { 
		return Constants.FUNCTION_NAMES.EXECUTE.name;
	}
}