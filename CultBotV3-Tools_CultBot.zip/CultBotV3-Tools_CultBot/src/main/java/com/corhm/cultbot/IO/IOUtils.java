package com.corhm.cultbot.IO;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.stream.Collectors;
import com.corhm.cultbot.Utils.BotException;
import sx.blah.discord.handle.impl.events.guild.channel.message.MessageReceivedEvent;

public class IOUtils {
	public static final String COMMAND_LOG = "../_files/commandLog.log";
	public static final String DATABASE = "../_files/Database.db";
		
	public static List<String> readFile(String fileName) throws BotException{
		return readFile(fileName, true);
	}	
	private static List<String> readFile(String fileName, boolean repeat) throws BotException{
		try(final BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			return br.lines().collect(Collectors.toList());
		} catch (IOException e) {
			if(repeat){
				writeFile(fileName);
				return readFile(fileName, false);
			}
			else{
				throw new BotException("Unable to open or create file '" + fileName + "'", e);
			}
		}
	}

	public static void writeFile(String fileName, List<String> lines) throws BotException{
		writeFile(fileName, lines.toArray(new String[lines.size()]));
	}
	public static void writeFile(String fileName, String... lines) throws BotException{
		writeFile(fileName, false, lines);
	}
	
	public static void writeInFile(String fileName, String... lines) throws BotException{
		writeFile(fileName, true, lines);
	}
	
	private static void writeFile(String fileName, Boolean append, String... lines) throws BotException{
		synchronized(fileName){
			try(FileWriter fw = new FileWriter(fileName, append)) {
				for(String line : lines)
					fw.write(line + System.lineSeparator());
			} catch (IOException e) {
				throw new BotException("Error writing lines to file '" + fileName + "'", e);
			}
		}
	}
	
	public static void logCommand(MessageReceivedEvent event) throws BotException{
		synchronized(COMMAND_LOG){
			String logEntry = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Timestamp(System.currentTimeMillis()))
							+ "\t" + event.getAuthor().getLongID() + "\t" + event.getAuthor().getDisplayName(event.getGuild())
							+ "\t" + event.getMessage().getContent();
			try {
				writeInFile(COMMAND_LOG, logEntry);
			} catch (BotException e) {
				System.out.println(logEntry);
				throw e;
			}
		}
	}
}
