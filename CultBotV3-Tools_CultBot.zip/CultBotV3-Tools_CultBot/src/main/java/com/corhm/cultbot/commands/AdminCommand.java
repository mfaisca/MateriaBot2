package com.corhm.cultbot.commands;
import com.corhm.cultbot.IO.SQL.SQLAccess;
import com.corhm.cultbot.Utils.BotException;
import com.corhm.cultbot.Utils.Constants;
import com.corhm.cultbot.Utils.Constants.HELP_TYPE;
import com.corhm.cultbot.Utils.MessageUtils;
import com.corhm.cultbot.Utils.SharedMethods;
import com.corhm.cultbot.commands._BaseCommand;
import com.corhm.cultbot.commands._Listener;

import sx.blah.discord.handle.impl.events.guild.channel.message.MessageReceivedEvent;
import sx.blah.discord.handle.obj.IGuild;

public class AdminCommand extends _BaseCommand{	
	public AdminCommand() {
		super("admin");
	}

	@Override
	protected void doStuff(final MessageReceivedEvent event) {
		if(event.getAuthor().getLongID() != Constants.QUETZ_ID)
			return;
		String msg = event.getMessage().getContent();
		String[] split = msg.split(" ");
		if(split[1].equalsIgnoreCase("new")) {
			IGuild newGuild = SharedMethods.client.getGuildByID(Long.parseLong(split[2]));
			if(newGuild != null) {
				if(newServer(event, Long.parseLong(split[2])))
					MessageUtils.sendMessage(event.getChannel(), "Server \"" + newGuild.getName() + "\" has been registered.\nThis server has " + newGuild.getTotalMemberCount() + " total users.");
			}else
				if(newServer(event, Long.parseLong(split[2])))
					MessageUtils.sendMessageWarn(event.getChannel(), "Server with ID \"" + split[2] + "\" has been registered.\nYou can now add " + event.getClient().getOurUser().mention() + " to the server.\nUse this link to invite the bot to your server:\n<https://discordapp.com/oauth2/authorize?client_id=531416878011383808&scope=bot&permissions=67497024>");
			return;
		}
		else if(msg.contains("shutdown") || msg.contains("stop")) {
			_Listener.SHUTDOWN_TIMER = System.currentTimeMillis() + 30 * 1000;
			MessageUtils.sendMessage(event.getChannel(), "Shutdown Initiated.\nThe bot will shutdown in 30 seconds.");
			SharedMethods.sleep(30 * 1000);
			MessageUtils.sendMessage(event.getChannel(), "Shutting down...");
			System.exit(0);
		}
	}
	
	private boolean newServer(MessageReceivedEvent event, Long guildId) {
		String[] msgs = event.getMessage().getContent().split(" "); // [2]=id | [3] = type | [4] = note
		try {
			SQLAccess.executeInsert("INSERT INTO servers VALUES(?, ?, ?, ?)", guildId, "$", msgs[3], msgs[4]);
			SQLAccess.executeInsert("INSERT INTO permissions VALUES(?, ?, ?, ?, ?, ?, ?)", "permission", "execute", guildId, 0, 0, 0, "OFF");
			SQLAccess.executeInsert("INSERT INTO permissions VALUES(?, ?, ?, ?, ?, ?, ?)", "emo", "delete", guildId, 0, 0, 0, "OFF");
			SQLAccess.executeInsert("INSERT INTO permissions VALUES(?, ?, ?, ?, ?, ?, ?)", "pull", "update", guildId, 0, 0, 0, "OFF");
			return true;
		} catch (BotException e) {
			MessageUtils.sendMessageError(event.getChannel(), e.getMessage());
			System.out.println(e.getMessage());
			return false;
		}
	}
	
	@Override
	protected String help(final MessageReceivedEvent event, Constants.HELP_TYPE helpType) {
		if(helpType.equals(HELP_TYPE.SHOW))	return null;
		return null;
	}
}