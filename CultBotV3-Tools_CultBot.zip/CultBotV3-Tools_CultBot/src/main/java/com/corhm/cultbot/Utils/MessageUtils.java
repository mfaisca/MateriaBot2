package com.corhm.cultbot.Utils;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import com.corhm.cultbot.commands._BaseCommand;
import sx.blah.discord.handle.impl.events.guild.channel.message.MessageReceivedEvent;
import sx.blah.discord.handle.obj.IChannel;
import sx.blah.discord.handle.obj.IEmoji;
import sx.blah.discord.handle.obj.IMessage;
import sx.blah.discord.handle.obj.IUser;
import sx.blah.discord.util.EmbedBuilder;

public class MessageUtils {
	public static final String S = " ︀︀";
    public static final String PARAM_PREFIX = " -";
    public static final String PARAM_SEPARATOR = ":";
    public static final int DISCORD_MESSAGE_LIMIT = 1800;
    public static final int DISCORD_EMBED_FIELD_LIMIT = 1024;
    public static final int DISCORD_EMBED_MAX_COLUMN_WIDTH = 30;
	public static final String UNKNOWN_EMOTE = "<:unknownSprite:394807008093667339>";
    
    public static final String empty(int l) {
    	String s = "";
    	for(int i = 0; i < l; i++)
    		s += S;
    	return s;
    }

    public static final String getMessage(final String message) {
    	return message.contains(" ") ? message.substring(message.indexOf(" ")+1).trim() : "";
    }
    public static final String getCommand(final String message) {
    	return message.startsWith(_BaseCommand.BOT_PREFIX) ? message.substring(_BaseCommand.BOT_PREFIX.length(), message.indexOf(" ")+1).trim() : null;
    }
    public static final Map<String, String> getMessageArguments(final MessageReceivedEvent event) {
    	return getMessageArguments(getMessage(event.getMessage().getContent()));
    }
    public static final Map<String, String> getMessageArguments(String message, String... dontLowerCase) {
    	message = " " + message;
    	final HashMap<String, String> map = new HashMap<String, String>();
    	String[] params = message.split(PARAM_PREFIX);
    	for(String param : params) {
    		param = param.trim();
    		if(param.equals("")) continue;
    		String[] values = param.split(PARAM_SEPARATOR);
    		if(!Arrays.asList(dontLowerCase).contains(values[0].toLowerCase()))
    			for(int v = 1; v < values.length; v++)
    				values[v] = values[v].toLowerCase();
    		if(values.length == 1) 
    			map.put(values[0].trim().toLowerCase(), "true");
    		else if(values.length == 2)
    			map.put(values[0].trim().toLowerCase(), values[1].trim());
    		else {
    			String value = values[1].trim();
    			for(int v = 2; v < values.length; v++)
    				value += PARAM_SEPARATOR + values[v].trim();
    			map.put(values[0].trim().toLowerCase(), value.trim());
    		}
    	}
    	return map;
    }
    public static final Map<String, String> getMessageArguments(String message, String defaultKey, String... dontLowerCase) {
    	message = " " + message;
    	final HashMap<String, String> map = new HashMap<String, String>();
    	String[] params = message.split(PARAM_PREFIX);
    	for(String param : params) {
    		param = param.trim();
    		if(param.equals("")) continue;
    		String[] values = param.split(PARAM_SEPARATOR);
    		if(!Arrays.asList(dontLowerCase).contains(values[0].toLowerCase()))
    			for(int v = 1; v < values.length; v++)
    				values[v] = values[v].toLowerCase();
    		if(values.length == 1) 
    			if(defaultKey != null)
    				map.put(defaultKey, values[0].trim().toLowerCase());
    			else
        			map.put(values[0].trim().toLowerCase(), "true");
    		else if(values.length == 2)
    			map.put(values[0].trim().toLowerCase(), values[1].trim());
    		else {
    			String value = values[1].trim();
    			for(int v = 2; v < values.length; v++)
    				value += PARAM_SEPARATOR + values[v].trim();
    			map.put(values[0].trim().toLowerCase(), value.trim());
    		}
    	}
    	return map;
    }


	public static final IMessage sendMessageError(IChannel channel, String message) {
    	return sendMessage(channel, ":no_entry: | " + message);
	}
	public static final IMessage sendMessageCrash(IChannel channel, String message) {
    	return sendMessage(channel, ":ambulance: | " + message);
	}
	public static final IMessage sendMessageInfo(IChannel channel, String message) {
    	return sendMessage(channel, ":information_source: | " + message);
	}
	public static final IMessage sendMessageWarn(IChannel channel, String message) {
    	return sendMessage(channel, ":warning: | " + message);
	}
    public static final IMessage sendMessage(final IChannel channel, final String message){
    	long time = System.currentTimeMillis();
    	boolean privateBlock = false;
    	while(true)
	    	try{
	    		try {
	    			channel.isDeleted();
	    		} catch(Exception e) { privateBlock = true; }
	    		return channel.sendMessage(message);
	    	} catch(Exception e){ 
	    		if(privateBlock || System.currentTimeMillis() - time > 30000)
	    			break;
	    		SharedMethods.sleep(1000L);
	    	}
    	return null;
    }
    
    public static final IMessage sendWhisper(final IUser user, final String message){
    	return sendMessage(user.getOrCreatePMChannel(), message);
    }
    public static final IMessage sendImage(final IChannel channel, final String imageURL){
    	return sendEmbed(channel, new EmbedBuilder().withImage(imageURL));
    }
    public static final IMessage sendEmbed(final IChannel channel, final EmbedBuilder embed){
    	long time = System.currentTimeMillis();
    	while(true)
	    	try{
	        	return channel.sendMessage(embed.build());
	    	} catch(Exception e){ 
	    		if(System.currentTimeMillis() - time > 30000)
	    			break;
	    		SharedMethods.sleep(1000L);
	    	}
    	return null;
    }
    public static final IMessage sendEmbed(final IChannel channel, String message, String emote) {
		EmbedBuilder builder = new EmbedBuilder();
		if(emote != null)
			builder.withThumbnail(emote);
		builder.withDesc(message);
		return sendEmbed(channel, builder);
    }
    
	public static final IMessage editMessage(IMessage message, String msg) {
    	long time = System.currentTimeMillis();
    	while(true)
	    	try{
	    		return message.edit(msg);
	    	} catch(Exception e){ 
	    		if(System.currentTimeMillis() - time > 30000)
	    			break;
	    		SharedMethods.sleep(1000L);
	    	}
    	return null;
	}
	public static final IMessage editMessage(IMessage message, EmbedBuilder msg) {
    	while(true)
	    	try{
	    		return message.edit(msg.build());
	    	} catch(Exception e){
	    		SharedMethods.sleep(1000L);
	    	}
	}
    
	public static final IMessage addReactions(IMessage message, IEmoji... reactions) {
    		for(IEmoji emote : reactions) {
    	    	while(true)
			    	try{
			    		message.addReaction(emote);
			    		SharedMethods.sleep(1000L);
			    		break;
			    	} catch(Exception e){
			    		SharedMethods.sleep(1000L);
			    	}
	    	}
    	return message;
	}
}