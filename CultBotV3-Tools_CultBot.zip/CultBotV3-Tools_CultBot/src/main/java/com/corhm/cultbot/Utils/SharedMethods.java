package com.corhm.cultbot.Utils;
import java.util.LinkedList;
import java.util.Optional;
import sx.blah.discord.api.IDiscordClient;
import sx.blah.discord.handle.obj.IEmoji;

public class SharedMethods {	
	public static IDiscordClient client;

	public static final void sleep(int sleep){
		try {
			Thread.sleep(sleep);
		} catch (InterruptedException e) {}
	}
	public static final void sleep(Long sleep){
		try {
			Thread.sleep(sleep);
		} catch (InterruptedException e) {}
	}

	public static final LinkedList<String> splitString(String s, int size) {
		LinkedList<String> split = new LinkedList<String>();
		int spaceIndex = s.indexOf(" ");
		if(spaceIndex != -1)
			while(spaceIndex < s.length()) {
				int nextLineIndex = s.indexOf("\n", 0);
				if(nextLineIndex != -1 && nextLineIndex < size) {
					split.add(s.substring(0, nextLineIndex));
					split.addAll(splitString(s.substring(nextLineIndex + 1), size));
					return split;
				}
				int nextSpaceIndex = s.indexOf(" ", spaceIndex + 1);
				if(nextSpaceIndex == -1){
					if(s.length() < size)
						split.addFirst(s);
					else {
						split.add(s.substring(0, spaceIndex));
						split.add(s.substring(spaceIndex+1));
					}
					return split;
				}
				if(nextSpaceIndex < size)
					spaceIndex = nextSpaceIndex;
				else {
					split.add(s.substring(0, spaceIndex));
					split.addAll(splitString(s.substring(spaceIndex + 1), size));
					return split;
				}
			}
		split.add(s);
		return split;
	}
	
	public static final String getEmoteByName(String name) {		
		Optional<IEmoji> o = Optional.ofNullable(getEmoteClassByName(name));
		return o.isPresent() ? "<:" + o.get().getName() + ":" + o.get().getLongID() + ">" : MessageUtils.UNKNOWN_EMOTE;
	}
	
	public static final IEmoji getEmoteClassByName(String name) {
		String name2 = name.replaceAll(" ", "").replaceAll("'", "").replaceAll("&", "");
		return client.getGuilds().stream()
				.filter(s -> s.getOwnerLongID() == Constants.QUETZ_ID)
				.flatMap(g -> g.getEmojis().stream())
				.filter(e -> e.getName().equalsIgnoreCase(name2))
				.findFirst().orElse(null);
	}
}