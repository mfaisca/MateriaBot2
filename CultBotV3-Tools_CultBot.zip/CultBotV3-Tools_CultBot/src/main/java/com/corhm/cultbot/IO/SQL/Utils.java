package com.corhm.cultbot.IO.SQL;
import java.util.Arrays;
import org.apache.commons.lang.ArrayUtils;

public class Utils {
	public static final String SEPARATOR = "|";
	
	public static String getStringArray(float[] strs) {
		return Arrays.asList(ArrayUtils.toObject(strs)).stream()
				.map(o -> ""+o)
				.reduce((s1, s2) -> {
					String s = s1 + SEPARATOR + s2;
					return s;
				})
				.orElse(null);
	}
	public static String getStringArray(String[] strs) {
		return Arrays.asList(strs).stream().reduce((s1, s2) -> (s1 + SEPARATOR + s2)).orElse(null);
	}
	public static String getStringArray(long[] strs) {
		return Arrays.asList(ArrayUtils.toObject(strs)).stream()
				.map(o -> ""+o)
				.reduce((s1, s2) -> {
					String s = s1 + SEPARATOR + s2;
					return s;
				})
				.orElse(null);
	}
	public static String[] getStringArray(String str) {
		if(str == null || str.equals("null") || str.length() == 0) return new String[0];
		return str.split(SEPARATOR);
	}
	public static long[] getLongArray(String str) {
		if(str == null || str.equals("null") || str.length() == 0) return new long[0];
		return ArrayUtils.toPrimitive(Arrays.asList(str.split('\\' + SEPARATOR)).stream().map(s -> Long.parseLong(s)).toArray(Long[]::new));
	}
	public static float[] getFloatArray(String str) {
		if(str == null || str.equals("null") || str.length() == 0) return new float[0];
		return ArrayUtils.toPrimitive(Arrays.asList(str.split('\\' + SEPARATOR)).stream().map(s -> Float.parseFloat(s)).toArray(Float[]::new));
	}
}