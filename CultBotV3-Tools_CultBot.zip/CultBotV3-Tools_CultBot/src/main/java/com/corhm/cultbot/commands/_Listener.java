package com.corhm.cultbot.commands;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import com.corhm.cultbot.IO.IOUtils;
import com.corhm.cultbot.Utils.BotException;
import com.corhm.cultbot.Utils.Constants;
import com.corhm.cultbot.Utils.LogUtils;
import com.corhm.cultbot.Utils.MessageUtils;
import com.corhm.cultbot.Utils.SharedMethods;
import sx.blah.discord.api.events.EventSubscriber;
import sx.blah.discord.handle.impl.events.guild.channel.message.MessageReceivedEvent;
import sx.blah.discord.handle.impl.events.guild.channel.message.MessageDeleteEvent;
import sx.blah.discord.handle.impl.events.guild.channel.message.reaction.ReactionAddEvent;
import sx.blah.discord.handle.obj.IUser;

public class _Listener{    
	public static final List<_BaseCommand> COMMANDS = new LinkedList<_BaseCommand>();
    private static final HashMap<IUser, Long> USER_COOLDOWNS = new HashMap<IUser, Long>();
    private static final int COOLDOWN = 5; //Seconds
    public static Long SHUTDOWN_TIMER = null;
	
	static {
		COMMANDS.addAll(Arrays.asList(
				new AdminCommand(),
				new PermissionCommand(),
				new EmoteCommand(),
				new AuthorCommand(),
				new HelpCommand(),
				new PatreonCommand(),
				new SimpleCommand("invite", "**MateriaBot Server:** <https://discord.gg/XCTC7jY>" + System.lineSeparator() + "**MateriaBot Patreon:** https://www.patreon.com/MateriaBot", "Command to show the invite link to the Support Server")
			));
	}
	
	public void commandExecution(final MessageReceivedEvent event, _BaseCommand cmd) {
		try {
			IOUtils.logCommand(event);
			cmd.doStuff(event);
		} catch (BotException e) {
			LogUtils.error(event, "Error writing to log command.", e);
		}
	}
	
    @EventSubscriber
    public void onMessageReceived(final ReactionAddEvent event){   
    	if(event.getMessage().getAuthor().getLongID() != SharedMethods.client.getOurUser().getLongID())
			return;
    	if(event.getUser().getLongID() == SharedMethods.client.getOurUser().getLongID())
    		return;
    	_Listener.COMMANDS.stream().filter(c -> c.getCommand().equals("test")).findFirst().orElse(null).doReactionStuff(event);
    }
	
    @EventSubscriber
    public void onMessageReceived(final MessageDeleteEvent event){
    	
    }
	
    @EventSubscriber
    public void onMessageReceived(final MessageReceivedEvent event){
    	if(!event.getMessage().getContent().startsWith(_BaseCommand.BOT_PREFIX))
			return;
    	String command = event.getMessage().getContent().substring(_BaseCommand.BOT_PREFIX.length());
    	command = command.contains(" ") ? command.substring(0, command.indexOf(" ")) : command;
    	_BaseCommand cmd = null;
    	for(_BaseCommand cur : _Listener.COMMANDS) {
			if(cur.getCommands().contains(command.toLowerCase())){
				if(checkPermission(cur.getCommand(), cur.getFunction(event), event)) {
					cmd = cur; 
					break;
				}
			}
		}
    	if(cmd != null) {
        	if(SHUTDOWN_TIMER != null) {
        		MessageUtils.sendMessage(event.getChannel(), "The bot is restarting, no further commands are being processed.");
        		return;
        	}
    		int cd = -1;
    		if((cd = userCooldown(event.getAuthor())) == -1) {
            	final _BaseCommand finalCmd = cmd;
        		new Thread(() -> commandExecution(event, finalCmd)).start();
    		}
    		else {
    			cd = (cd/1000)+1;
    			MessageUtils.sendMessageWarn(event.getChannel(), "Please wait " + cd + " second" + (cd == 1 ? "" : "s") + " to use another command.");
    		}
    	}else {
			//MessageUtils.sendMessageWarn(event.getChannel(), "You don't have enough permissions to run this command.");
    	}
    } 

	protected final Boolean checkPermission(final String command, final String function, final MessageReceivedEvent event){
		try {
			boolean hasPermission = PermissionCommand.hasPermission(command, function, event);
			return hasPermission;
		} catch (BotException e) {
			if(e.getErrorCode() == 201)
				MessageUtils.sendMessageWarn(event.getChannel(), e.getMessage());
			else 
				MessageUtils.sendMessageError(event.getChannel(), e.getMessage());
			return false;
		}
    }
    
    private static final int userCooldown(IUser user) {
    	if(USER_COOLDOWNS.containsKey(user) && user.getLongID() != Constants.QUETZ_ID) {
    		long cooldown = USER_COOLDOWNS.get(user);
    		if(cooldown > System.currentTimeMillis())
    			return (int) (cooldown - System.currentTimeMillis());
    	}
		USER_COOLDOWNS.put(user, System.currentTimeMillis() + (COOLDOWN * 1000));
		return -1;
    }
}