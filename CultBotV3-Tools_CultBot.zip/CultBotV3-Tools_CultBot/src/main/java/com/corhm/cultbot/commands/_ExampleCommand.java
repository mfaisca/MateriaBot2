package com.corhm.cultbot.commands;
import com.corhm.cultbot.Utils.Constants;
import com.corhm.cultbot.Utils.Constants.HELP_TYPE;

import sx.blah.discord.handle.impl.events.guild.channel.message.MessageReceivedEvent;

public class _ExampleCommand extends _BaseCommand{	
	public _ExampleCommand() {
		super("example");
	}

	@Override
	protected void doStuff(final MessageReceivedEvent event) {
		
	}
	
	@Override
	protected String help(final MessageReceivedEvent event, Constants.HELP_TYPE helpType) {
		String ret = "";
		if(Constants.HELP_TYPE.SHORT.equals(helpType)){
			ret += "Short";
		}else{
			ret += "```md" + System.lineSeparator();
			ret += "Talk Command" + System.lineSeparator();
			ret += "===============" + System.lineSeparator();
			ret += help(event, HELP_TYPE.SHORT) + System.lineSeparator();
			ret += System.lineSeparator();
			ret += "[*][Usage][*]" + System.lineSeparator();
			ret += "* " + _BaseCommand.BOT_PREFIX + "example <Message>" + System.lineSeparator();
			ret += ">    Blablabla" + System.lineSeparator();
			ret += "```";
		}
		return ret;
	}
}