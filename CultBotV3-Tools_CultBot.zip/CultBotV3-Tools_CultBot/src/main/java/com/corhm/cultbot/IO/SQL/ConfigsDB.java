package com.corhm.cultbot.IO.SQL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.corhm.cultbot.Utils.BotException;

public class ConfigsDB {
	public static final String GENERAL_BOT_TOKEN_KEY = "GENERAL_BOT_TOKEN_KEY";
	public static final String BRAVEEXVIUS_TOKEN_KEY = "BE_BOT_TOKEN_KEY";
	public static final String OPERAOMNIA_TOKEN_KEY = "OO_BOT_TOKEN_KEY";
	public static final String CLEVERBOT_TOKEN_KEY = "CLEVERBOT_TOKEN_KEY";
	public static final String DEBUG_TOKEN_KEY = "DEBUG_TOKEN_KEY";
	
	public static final void buildTables() throws SQLException{
		try(Statement statement = SQLAccess.getConnection().createStatement()){
			statement.executeUpdate("CREATE TABLE bot_configs (key string COLLATE nocase, value string COLLATE nocase, PRIMARY KEY(key))");
			statement.executeUpdate("CREATE TABLE users_emotes (name string COLLATE nocase, guildId INTEGER, userid integer NOT NULL, url string NOT NULL, PRIMARY KEY(name, serverID))");
			statement.executeUpdate("CREATE TABLE permissions (command TEXT COLLATE nocase, function TEXT COLLATE nocase DEFAULT 'execute', guildId INTEGER, roleId INTEGER, channelId INTEGER, userId INTEGER, permission TEXT COLLATE nocase NOT NULL, PRIMARY KEY(command,guildId,function,userId,channelId,roleId))");
			statement.executeUpdate("CREATE TABLE servers (id INTEGER, prefix TEXT COLLATE nocase, type TEXT COLLATE nocase, PRIMARY KEY(id))");
			setKeyValue(GENERAL_BOT_TOKEN_KEY, null);
			setKeyValue(BRAVEEXVIUS_TOKEN_KEY, null);
			setKeyValue(OPERAOMNIA_TOKEN_KEY, null);
			setKeyValue(DEBUG_TOKEN_KEY, null);
		} catch(Exception e) { }
	}

	public static void buildBraveExviusTables() {
		try(Statement statement = SQLAccess.getConnection().createStatement()){
			statement.executeUpdate("CREATE TABLE users_friendcodes_be (userId TEXT, friendCode TEXT NOT NULL, PRIMARY KEY(userId))");
			statement.executeUpdate("CREATE TABLE dungeons (id integer PRIMARY KEY, name string collate nocase, icon string collate nocase)");
			statement.executeUpdate("CREATE TABLE dungeons_missions (id integer PRIMARY_KEY, dungeonId integer, name string collate nocase, type string collate nocase, waveCount integer, "
					+ "costType string, cost integer, reward string, gil integer, exp integer, continueAllowed integer, escapeAllowed integer, challenge1 string, challenge2 string, challenge3 string, challenge4 string, "
					+ "FOREIGN KEY(dungeonId) REFERENCES dungeons(id))");
			statement.executeUpdate("CREATE TABLE materias (id integer PRIMARY_KEY, name string collate nocase, compendiumId integer, "
					+ "compendiumShown integer, skills string, effects string, uniqueEquip integer, priceBuy integer, priceSell integer, "
					+ "icon string collate nocase, descShort string collate nocase, descLong string collate nocase)");
			statement.executeUpdate("CREATE TABLE equipments (id integer PRIMARY_KEY, name string collate nocase, compendiumId integer, "
					+ "compendiumShown integer, rarity integer, typeId integer, slotId integer, isTwoHanded integer, dmgVariance string, accuracy integer, requirements string, skills string, effects string, "
					+ "statsHP integer, statsMP integer, statsATK integer, statsDEF integer, statsMAG integer, statsSPR integer, "
					+ "elementResistFire integer, elementResistIce integer, elementResistLightning integer, elementResistWater integer, elementResistWind integer, elementResistEarth integer, elementResistLight integer, elementResistDark integer, "
					+ "elementInflictFire integer, elementInflictIce integer, elementInflictLightning integer, elementInflictWater integer, elementInflictWind integer, elementInflictEarth integer, elementInflictLight integer, elementInflictDark integer, "
					+ "statusResistPoison integer, statusResistBlind integer, statusResistSleep integer, statusResistSilence integer, statusResistParalyze integer, statusResistConfusion integer, statusResistDisease integer, statusResistPetrify integer, statusResistStop integer, statusResistCharm integer, statusResistDeath integer, "
					+ "statusInflictPoison integer, statusInflictBlind integer, statusInflictSleep integer, statusInflictSilence integer, statusInflictParalyze integer, statusInflictConfusion integer, statusInflictDisease integer, statusInflictPetrify integer, statusInflictStop integer, statusInflictCharm integer, statusInflictDeath integer, "
					+ "priceBuy integer, priceSell integer, icon string collate nocase, descShort string collate nocase, descLong string collate nocase)");
			statement.executeUpdate("CREATE TABLE units (id integer PRIMARY KEY, name string collate nocase, minRarity integer, maxRarity integer, job string collate nocase, sexId integer, tribeId integer, equipables string collate nocase, tmrType string collate nocase, tmrId integer)");
			statement.executeUpdate("CREATE TABLE units_entries (entryId integer PRIMARY KEY, unitId integer, compendiumId integer, rarity integer, growthPattern integer, limitBurstId integer, attackDamage string, attackFrames string, maxLBDrops integer, "
					+ "description string, summon string, evolution string, affinity string, fusion string, white integer, black integer, green integer, blue integer, "
					+ "hpMin integer, hpMax integer, hpPot integer, mpMin integer, mpMax integer, mpPot integer, atkMin integer, atkMax integer, atkPot integer, defMin integer, defMax integer, defPot integer, magMin integer, magMax integer, magPot integer, sprMin integer, sprMax integer, sprPot integer, "
					+ "fire integer, ice integer, lightning integer, water integer, wind integer, earth integer, light integer, dark integer, "
					+ "poison integer, blind integer, sleep integer, silence integer, paralyze integer, confusion integer, disease integer, petrify integer)");
			statement.executeUpdate("CREATE TABLE units_skills (unitId integer, skillId integer, rarity integer, level integer, type string collate nocase, PRIMARY KEY(unitId, skillId))");
			statement.executeUpdate("CREATE TABLE skills (id integer PRIMARY KEY, compendiumId integer, "
					+ "name string collate nocase, type string collate nocase, rarity integer, "
					+ "active integer, uniqu integer, magicType string, mpCost integer, "
					+ "attackCount string, attackDamage string, attackFrames string, effectFrames string, "
					+ "elementInflictFire integer, elementInflictIce integer, elementInflictLightning integer, elementInflictWater integer, elementInflictWind integer, elementInflictEarth integer, elementInflictLight integer, elementInflictDark integer, "
					+ "moveType integer, motionType integer, effectType string, restrictions string, "
					+ "descShort string, descLong string, icon string collate nocase)");
			statement.executeUpdate("CREATE TABLE skills_effects (skillId integer, target1 integer, target2 integer, effectType integer, description string collate nocase, raw string collate nocase, "
					+ "FOREIGN KEY(skillId) REFERENCES skills(id))");
		} catch(Exception e) { }
	}

	public static void buildOperaOmniaTables() {
		try(Statement statement = SQLAccess.getConnection().createStatement()){
			statement.executeUpdate("CREATE TABLE users_friendcodes_oo_gl (userId TEXT, "
					+ "friendCode TEXT, unitShared TEXT, PRIMARY KEY(userId))");
			statement.executeUpdate("CREATE TABLE users_friendcodes_oo_jp (userId TEXT, "
					+ "friendCode TEXT, unitShared TEXT, PRIMARY KEY(userId))");
			statement.executeUpdate("CREATE TABLE users_pull_statistics (userId INTEGER, gems INTEGER DEFAULT 0, tickets INTEGER DEFAULT 0, " + 
					"countEX INTEGER DEFAULT 0, count35 INTEGER DEFAULT 0, count15 INTEGER DEFAULT 0, countOffBanner INTEGER DEFAULT 0, PRIMARY KEY(userId)");
		} catch(Exception e) { }
	}
	
	public static String getKeyValue(String key) throws BotException{
		try(ResultSet result = SQLAccess.executeSelect("SELECT * FROM bot_configs WHERE key = ?", key)) {
			String res = null;
			if(result.next())
				res = result.getString("value");
			return res;
		} catch (SQLException e) {
			throw new BotException("Error communicating with the database!", e);
		}
	}
	public static void setKeyValue(String key, String value) throws BotException{
		SQLAccess.executeInsert("INSERT OR REPLACE INTO bot_configs VALUES(?, ?)", key, value);
	}
	
	public static String getCommandValue(String command) throws BotException{
		try(ResultSet result = SQLAccess.executeSelect("SELECT * FROM bot_commands WHERE commandName = ?", command)) {
			String res = null;
			if(result.next())
				res = result.getString("message");
			return res;
		} catch (SQLException e) {
			throw new BotException("Error communicating with the database!", e);
		}
	}
	public static void setCommandValue(String command, String message) throws BotException{
		SQLAccess.executeInsert("INSERT OR REPLACE INTO bot_commands VALUES(?, ?)", command, message);
	}
}